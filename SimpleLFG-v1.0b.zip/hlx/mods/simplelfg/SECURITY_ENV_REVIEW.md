# Security and privacy review — 2026-10-25

SimpleLFG 0.1.11-test is a public native client. It contains no shared admission
secret and requires no player environment variables or copied credentials.
Names and Steam codes remain self-reported; this is not proof of Steam ownership.

## Authentication and privacy

The HTTPS session endpoint automatically returns a public random address and a
private 256-bit bearer verifier. The client retains credentials only in memory;
the server retains a verifier digest and compares it in constant time. Every
listing write, privacy change, message send and inbox read requires its session.
Ownership is never inferred from a name or Steam code. Session idle expiry is
30 minutes; listings and messages expire after 15 minutes. Closing the panel
stops networking and retains the credential; logout/identity changes discard it.
Steam codes are optional and blank on a fresh installation. Public sharing starts
off, including a one-time reset of older public consent; saved contact details
are retained. Enabling public sharing requires a reminder that players can
whisper or use private messages instead. Steam codes are hidden by default; public sharing and every publish/send remain
explicit actions. An admin credential exists only on the server, outside the
web root, with the existing WGU role/CSRF protections.

## Trusted proxy and resource boundary

Only Caddy reaches the loopback Uvicorn listener. Caddy uses CF-Connecting-IP only when its connection peer belongs to the
explicit published Cloudflare allowlist and the value is a single IP literal.
For all other peers it overwrites X-Forwarded-For with the socket peer. Forwarded,
X-Real-IP and Cloudflare identity headers are stripped before reaching Uvicorn.
Uvicorn trusts only loopback proxy peers; the application never parses forwarding
headers. Limits use that validated address, grouping IPv6 by /64. Any future CDN
requires an explicit verified upstream trust policy first.

The request guard counts rejected requests, limits bodies to 8 KiB before JSON
parsing (including chunked bodies), and bounds both limiter keys and lifetimes.
IP budgets persist independently of session churn. Per-session, per-recipient,
per-IP and global capacity checks reject excess work without evicting another
player's unexpired messages. Accepted inbox cursors acknowledge received rows.
Runtime limits can be configured only by operators; defaults are documented in
server/ADMIN_DEPLOYMENT.md. The single-worker service uses a dedicated unprivileged
account, restricted writable state, filesystem hardening and resource bounds.

## Event delivery and data handling

Authenticated /api/lfg/events streams carry only sync/listings/chat/expired
invalidations, with a 15-second heartbeat. Private notifications target only the
recipient session. Event queues have eight entries and coalesce overflow into a
full sync; streams are capped globally and per IP/session. The native decoder
bounds headers, lines and events and supports arbitrary HTTP chunk boundaries.
A separate worker owns the TLS context; cancellation interrupts the OS socket
without freeing TLS state on the UI thread. Healthy streams suppress idle polls.
Fallback polling is 15 seconds for listings and 10 seconds for inboxes, with
Retry-After/backoff and no overlapping requests. Reopening fetches fresh state;
notifications during a pending fetch schedule another fetch rather than being lost.

Pydantic rejects unknown fields/coerced types and validates lengths, Steam codes,
party sizes and controls. Punctuation remains plain text. Browser output uses
textContent, and Steam links accept only numeric codes. SQLite queries remain
parameterized. Private responses are no-store; CORS is limited to the production
site without credentialed cross-origin access. Logging excludes bodies/tokens.

## Verification and limits

See evidence/security-release.json for the release's checks and deployment records.
Tests write only to isolated fixtures. Production checks read public listings,
health, listener and service configuration; no production listing/message is sent.
Anonymous access cannot prove official-client use or stop a distributed bandwidth
attack. Published source and binaries are intentionally sufficient to implement
another compatible client. Quotas bound impact; they are not device attestation.
Actual in-game visuals/input/coexistence remain user-operated acceptance checks.

Cloudflare is already in the live path. The route-scoped source allowlist was
verified on 2026-10-25 against [IPv4](https://www.cloudflare.com/ips-v4) and
[IPv6](https://www.cloudflare.com/ips-v6). Other upstreams require explicit review.
The Caddy fixture tests both trusted CDN visitors and direct untrusted callers,
including forged headers, distinct visitors, IPv6 /64 budgets and session churn.

## 0.1.8 temporary responder

The server-owned is_test marker identifies the temporary SimpleLFG Test contact.
Clients cannot submit this marker. It uses a normal private session and ordinary
queue/send/recipient limits. Echoes go only to the sender and are bounded for the
native UTF-16 composer. Credentials remain in memory. An operator-owned absolute
expiry controls availability across restarts; no player setup is required.

## Explicit Steam contact lookup (0.1.9)

Messages only checks the selected peer's incoming history after the user clicks
Steam contact or its context-menu action. It first checks the entire conversation
for our bracketed Steam tags. Only if no valid tag succeeds does it check general
formats: individual public SteamID64, Steam2, Steam3, labelled numeric codes, or
a standalone 5-10 digit account code. It ignores the user's outgoing messages
and other conversations. There is no string watcher, automatic message hyperlink,
external lookup request, or automatic profile launch.

The reviewed action constructs only https://steamcommunity.com/profiles/ plus a
validated decimal individual ID. It validates again before dispatching the URL
from the observation phase. No received URL is executed. Codes are unverified,
self-reported contact data; format validation does not establish ownership.

Format references: [Steamworks identity documentation](https://partner.steamgames.com/doc/features/auth)
and [Valve's public Steam ID layout and validation](https://github.com/ValveSoftware/GameNetworkingSockets/blob/master/include/steam/steamclientpublic.h).

## Optional class and restored admin (0.1.11)

Optional player_class metadata accepts only blank, Warrior, Mage, Priest or Rogue.
It does not claim recruiting slots or establish identity. Old listings omit it
safely. The website board uses safe text rendering and an enum check.

The /admin/#lfg shell and router/module wiring are restored. PHP retains actual
WGU administrator checks and CSRF checks for moderation writes; its gateway URL
is constrained to the loopback admin endpoint, and its key remains server-only.
The public shortcut /lfg serves the maintained board; /lfg-board redirects there.
Isolated PHP tests cover role denial, CSRF, derived actor, invalid upstream URL,
and no credential exposure. Production verification only reads state and public
pages; no production accounts or moderation actions were created.
